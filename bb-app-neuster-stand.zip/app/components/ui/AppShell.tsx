"use client";

import "./ui.css";
import type { ReactNode } from "react";
import { useState } from "react";
import { usePathname } from "next/navigation";

type AppShellProps = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  backHref?: string;
  backLabel?: string;
  action?: ReactNode;
};

const navigation = [
  { href: "/", icon: "⌂", label: "Übersicht" },
  { href: "/baustellen", icon: "▦", label: "Baustellen" },
  { href: "/instruktionen", icon: "✓", label: "Checklisten" },
  { href: "/dokumente", icon: "▤", label: "Dokumente" },
  { href: "/geraete", icon: "⚙", label: "Geräte" },
  { href: "/mitarbeiter", icon: "♧", label: "Mitarbeiter" },
  { href: "/kalender", icon: "□", label: "Kalender" },
];

export default function AppShell({
  children,
  title,
  subtitle,
  backHref,
  backLabel = "Zurück",
  action,
}: AppShellProps) {
  const pathname = usePathname();
  const [menuOffen, setMenuOffen] = useState(false);

  function istAktiv(href: string, label: string) {
    if (label === "Baustellen") {
      return pathname.startsWith("/baustellen");
    }

    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  }

  return (
    <div className="bb-shell">
      <aside
        className={`bb-sidebar ${menuOffen ? "mobile-open" : ""}`}
      >
        <button
          type="button"
          className="bb-sidebar-close"
          onClick={() => setMenuOffen(false)}
          aria-label="Menü schliessen"
        >
          ×
        </button>

        <a
          href="/"
          className="bb-brand bb-brand-logo"
          aria-label="B&B Schadstoffsanierung – Übersicht"
        >
          <img
            src="/bb-logo.png"
            alt="B&B Schadstoffsanierung"
          />
        </a>

        <nav className="bb-nav">
          {navigation.map((eintrag) => (
            <a
              key={eintrag.label}
              href={eintrag.href}
              onClick={() => setMenuOffen(false)}
              className={
                istAktiv(eintrag.href, eintrag.label) ? "active" : ""
              }
            >
              <span>{eintrag.icon}</span>
              {eintrag.label}
            </a>
          ))}
        </nav>

        <div className="bb-sidebar-footer">
          <span>◇</span>
          Sicherheit hat Priorität
        </div>
      </aside>

      {menuOffen && (
        <button
          type="button"
          className="bb-sidebar-overlay"
          onClick={() => setMenuOffen(false)}
          aria-label="Menü schliessen"
        />
      )}

      <main className="bb-main">
        <header className="bb-topbar">
          <div className="bb-topbar-left">
            <button
              type="button"
              className="bb-mobile-menu"
              onClick={() => setMenuOffen(true)}
              aria-label="Navigation öffnen"
            >
              ☰
            </button>

            <div className="bb-topbar-context">
              B&amp;B Projektmanagement
            </div>
          </div>

          <div className="bb-topbar-actions">
            <button
              className="bb-icon-button"
              type="button"
              aria-label="Benachrichtigungen"
            >
              ♧
              <span className="bb-notification-dot">3</span>
            </button>

            <div className="bb-user-avatar">L</div>
          </div>
        </header>

        <div className="bb-content">
          {(title || backHref || action) && (
            <section className="bb-page-header">
              <div>
                {backHref && (
                  <a href={backHref} className="bb-back-link">
                    ← {backLabel}
                  </a>
                )}

                {title && <h1>{title}</h1>}
                {subtitle && <p>{subtitle}</p>}
              </div>

              {action && (
                <div className="bb-page-header-action">{action}</div>
              )}
            </section>
          )}

          {children}
        </div>
      </main>
    </div>
  );
}
