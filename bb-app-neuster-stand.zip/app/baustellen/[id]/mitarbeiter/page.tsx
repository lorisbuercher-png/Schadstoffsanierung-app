"use client";

import AppShell from "../../../components/ui/AppShell";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

type Mitarbeiter = {
  id: string;
  vorname: string;
  nachname: string;
  funktion: string;
  aktiv: boolean;
};

type Baustelle = {
  id: string;
  nummer: string;
  projektname: string;
};

export default function BaustellenMitarbeiter() {
  const params = useParams();
  const id = params.id as string;

  const [baustelle, setBaustelle] = useState<Baustelle | null>(null);
  const [mitarbeiter, setMitarbeiter] = useState<Mitarbeiter[]>([]);
  const [zugewiesen, setZugewiesen] = useState<string[]>([]);

  useEffect(() => {
    const alleBaustellen = JSON.parse(
      localStorage.getItem("baustellen") || "[]"
    );

    setBaustelle(
      alleBaustellen.find((b: Baustelle) => b.id === id) || null
    );

    const alleMitarbeiter = JSON.parse(
      localStorage.getItem("mitarbeiter") || "[]"
    );

    setMitarbeiter(
      alleMitarbeiter.filter((m: Mitarbeiter) => m.aktiv)
    );

    setZugewiesen(
      JSON.parse(
        localStorage.getItem(`baustellen-mitarbeiter-${id}`) || "[]"
      )
    );
  }, [id]);

  function toggle(mitarbeiterId: string) {
    setZugewiesen((prev) =>
      prev.includes(mitarbeiterId)
        ? prev.filter((x) => x !== mitarbeiterId)
        : [...prev, mitarbeiterId]
    );
  }

  function speichern() {
    localStorage.setItem(
      `baustellen-mitarbeiter-${id}`,
      JSON.stringify(zugewiesen)
    );

    alert("Baustellen-Team gespeichert.");
  }

  if (!baustelle) {
    return (
      <main className="min-h-screen bg-slate-50 p-10">
        Baustelle wird geladen...
      </main>
    );
  }

  return (
    <AppShell
      title="Baustellenmitarbeiter"
      subtitle="Mitarbeiter dieser Baustelle zuweisen."
      backHref={`/baustellen/${id}`}
      backLabel="Zur Baustelle"
    >

      

      <div className="mx-auto max-w-6xl p-6">

        <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">

          <div className="border-b p-5">

            <h2 className="text-lg font-bold">
              Mitarbeiter zuweisen
            </h2>

            <p className="text-sm text-slate-500">
              {zugewiesen.length} Personen ausgewählt
            </p>

          </div>

          {mitarbeiter.length === 0 ? (

            <div className="p-10 text-center">

              <p className="text-slate-500">
                Noch keine aktiven Mitarbeiter vorhanden.
              </p>

              <a
                href="/mitarbeiter"
                className="mt-4 inline-block rounded-xl bg-[#17565d] px-5 py-3 font-bold text-black"
              >
                Mitarbeiter erfassen
              </a>

            </div>

          ) : (

            <div className="divide-y">

              {mitarbeiter.map((m) => {

                const aktiv = zugewiesen.includes(m.id);

                return (
                  <label
                    key={m.id}
                    className={`flex cursor-pointer items-center gap-4 p-5 ${
                      aktiv ? "bg-[#f5f9f9]" : ""
                    }`}
                  >

                    <input
                      type="checkbox"
                      checked={aktiv}
                      onChange={() => toggle(m.id)}
                      className="h-5 w-5"
                    />

                    <div className="flex-1">

                      <div className="font-bold">
                        {m.vorname} {m.nachname}
                      </div>

                      <div className="text-sm text-slate-500">
                        {m.funktion}
                      </div>

                    </div>

                    {aktiv && (
                      <span className="rounded-full bg-[#17565d] px-3 py-1 text-xs font-bold text-black">
                        Zugewiesen
                      </span>
                    )}

                  </label>
                );
              })}

            </div>

          )}

          <div className="flex justify-end border-t p-5">

            <button
              type="button"
              onClick={speichern}
              className="rounded-xl bg-[#17565d] px-6 py-3 font-bold text-black hover:bg-[#12464c]"
            >
              Team speichern
            </button>

          </div>

        </div>

      </div>

    </AppShell>
  );
}
