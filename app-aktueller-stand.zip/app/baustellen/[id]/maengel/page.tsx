"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";

type Prioritaet = "kritisch" | "hoch" | "normal";
type Status = "offen" | "in-bearbeitung" | "behoben";

type Mangel = {
  id: string;
  titel: string;
  beschreibung: string;
  prioritaet: Prioritaet;
  status: Status;
  quelle: string;
  verantwortlich: string;
  frist: string;
  erstelltAm: string;
  behobenAm?: string;
  suvaPunkt?: number;
};

export default function MaengelPage() {
  const params = useParams();
  const id = params.id as string;

  const [maengel, setMaengel] = useState<Mangel[]>([]);
  const [formularOffen, setFormularOffen] = useState(false);

  const [titel, setTitel] = useState("");
  const [beschreibung, setBeschreibung] = useState("");
  const [prioritaet, setPrioritaet] =
    useState<Prioritaet>("normal");
  const [quelle, setQuelle] = useState("Manuell");
  const [verantwortlich, setVerantwortlich] = useState("");
  const [frist, setFrist] = useState("");

  const storageKey = `maengel-${id}`;

  useEffect(() => {
    const raw = localStorage.getItem(storageKey);

    if (raw) {
      try {
        const daten = JSON.parse(raw);
        if (Array.isArray(daten)) setMaengel(daten);
      } catch {}
    }
  }, [storageKey]);

  function speichern(neu: Mangel[]) {
    setMaengel(neu);
    localStorage.setItem(storageKey, JSON.stringify(neu));
  }

  function mangelErstellen() {
    if (!titel.trim()) {
      alert("Bitte einen Mangel eingeben.");
      return;
    }

    const neu: Mangel = {
      id: crypto.randomUUID(),
      titel: titel.trim(),
      beschreibung: beschreibung.trim(),
      prioritaet,
      status: "offen",
      quelle,
      verantwortlich: verantwortlich.trim(),
      frist,
      erstelltAm: new Date().toISOString(),
    };

    speichern([neu, ...maengel]);

    setTitel("");
    setBeschreibung("");
    setPrioritaet("normal");
    setQuelle("Manuell");
    setVerantwortlich("");
    setFrist("");
    setFormularOffen(false);
  }

  function statusAendern(mangelId: string, status: Status) {
    const aktualisiert = maengel.map((mangel) =>
      mangel.id === mangelId
        ? {
            ...mangel,
            status,
            behobenAm:
              status === "behoben"
                ? new Date().toISOString()
                : undefined,
          }
        : mangel
    );

    speichern(aktualisiert);

    const mangel = aktualisiert.find(
      (eintrag) => eintrag.id === mangelId
    );

    if (
      status === "behoben" &&
      mangel?.quelle === "SUVA Audit" &&
      mangel?.suvaPunkt
    ) {
      const auditKey = `suva-audit-${id}`;
      const raw = localStorage.getItem(auditKey);

      if (raw) {
        try {
          const audit = JSON.parse(raw);

          if (audit[mangel.suvaPunkt]) {
            audit[mangel.suvaPunkt] = {
              ...audit[mangel.suvaPunkt],
              status: "offen",
              notiz:
                (audit[mangel.suvaPunkt].notiz || "") +
                "\nMassnahme behoben – Nachkontrolle erforderlich.",
            };

            localStorage.setItem(
              auditKey,
              JSON.stringify(audit)
            );
          }
        } catch {}
      }
    }
  }

  const offeneMaengel = useMemo(
    () => maengel.filter((m) => m.status !== "behoben"),
    [maengel]
  );

  const kritischeMaengel = offeneMaengel.filter(
    (m) => m.prioritaet === "kritisch"
  ).length;

  const behoben = maengel.filter(
    (m) => m.status === "behoben"
  ).length;

  return (
    <main className="min-h-screen bg-[#f6f7f8] text-[#17181c]">

      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-5">

          <a
            href={`/baustellen/${id}`}
            className="text-sm font-medium text-slate-500 hover:text-black"
          >
            ← Zurück zur Baustelle
          </a>

          <div className="mt-5 flex flex-col justify-between gap-4 md:flex-row md:items-end">

            <div>
              <div className="text-[10px] font-black uppercase tracking-[0.18em] text-[#d8951f]">
                BAUSTELLENKONTROLLE
              </div>

              <h1 className="mt-2 text-3xl font-black">
                Mängelmanagement
              </h1>

              <p className="mt-1 text-sm text-slate-500">
                Feststellungen, Massnahmen und Erledigungen dokumentieren.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setFormularOffen(!formularOffen)}
              className="rounded-xl bg-[#F2B632] px-5 py-3 text-sm font-black text-black"
            >
              + Mangel erfassen
            </button>

          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl space-y-5 p-6">

        <section className="grid gap-4 sm:grid-cols-3">

          <div className="rounded-[22px] bg-[#18191c] p-5 text-white">
            <div className="text-xs text-slate-400">
              Offene Mängel
            </div>
            <strong className="mt-2 block text-3xl">
              {offeneMaengel.length}
            </strong>
          </div>

          <div
            className={`rounded-[22px] p-5 ${
              kritischeMaengel > 0
                ? "bg-red-600 text-white"
                : "border border-slate-200 bg-white"
            }`}
          >
            <div className="text-xs opacity-70">
              Kritisch
            </div>
            <strong className="mt-2 block text-3xl">
              {kritischeMaengel}
            </strong>
          </div>

          <div className="rounded-[22px] border border-slate-200 bg-white p-5">
            <div className="text-xs text-slate-500">
              Behoben
            </div>
            <strong className="mt-2 block text-3xl text-green-600">
              {behoben}
            </strong>
          </div>

        </section>

        {formularOffen && (
          <section className="rounded-[22px] border border-[#F2B632] bg-white p-6 shadow-sm">

            <div className="mb-5">
              <div className="text-[10px] font-black uppercase tracking-[0.18em] text-[#a56c0c]">
                NEUER MANGEL
              </div>
              <h2 className="mt-1 text-xl font-black">
                Feststellung erfassen
              </h2>
            </div>

            <div className="grid gap-4 md:grid-cols-2">

              <div className="md:col-span-2">
                <label className="text-xs font-bold">
                  Mangel / Feststellung
                </label>

                <input
                  value={titel}
                  onChange={(e) => setTitel(e.target.value)}
                  placeholder="z.B. Folienabtrennung beschädigt"
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-[#F2B632]"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-xs font-bold">
                  Beschreibung / Massnahme
                </label>

                <textarea
                  value={beschreibung}
                  onChange={(e) => setBeschreibung(e.target.value)}
                  placeholder="Feststellung und erforderliche Massnahme..."
                  className="mt-2 min-h-28 w-full resize-none rounded-xl border border-slate-200 bg-slate-50 p-4 outline-none focus:border-[#F2B632]"
                />
              </div>

              <div>
                <label className="text-xs font-bold">
                  Priorität
                </label>

                <select
                  value={prioritaet}
                  onChange={(e) =>
                    setPrioritaet(e.target.value as Prioritaet)
                  }
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                >
                  <option value="normal">Normal</option>
                  <option value="hoch">Hoch</option>
                  <option value="kritisch">Kritisch</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold">
                  Quelle
                </label>

                <select
                  value={quelle}
                  onChange={(e) => setQuelle(e.target.value)}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                >
                  <option>Manuell</option>
                  <option>Tagescheck</option>
                  <option>SUVA Audit</option>
                  <option>AS10 Kontrolle</option>
                  <option>Baustellenjournal</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold">
                  Verantwortlich
                </label>

                <input
                  value={verantwortlich}
                  onChange={(e) =>
                    setVerantwortlich(e.target.value)
                  }
                  placeholder="Name"
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                />
              </div>

              <div>
                <label className="text-xs font-bold">
                  Frist
                </label>

                <input
                  type="date"
                  value={frist}
                  onChange={(e) => setFrist(e.target.value)}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"
                />
              </div>

            </div>

            <div className="mt-5 flex justify-end gap-3">

              <button
                type="button"
                onClick={() => setFormularOffen(false)}
                className="rounded-xl bg-slate-100 px-5 py-3 text-sm font-bold"
              >
                Abbrechen
              </button>

              <button
                type="button"
                onClick={mangelErstellen}
                className="rounded-xl bg-[#18191c] px-5 py-3 text-sm font-black text-white"
              >
                Mangel speichern
              </button>

            </div>

          </section>
        )}

        {kritischeMaengel > 0 && (
          <section className="rounded-[22px] border border-red-300 bg-red-50 p-5">
            <strong className="text-red-700">
              ⛔ Kritischer Mangel vorhanden
            </strong>
            <p className="mt-1 text-sm text-red-700">
              Mindestens ein kritischer Mangel ist noch nicht behoben.
            </p>
          </section>
        )}

        <section className="rounded-[22px] border border-slate-200 bg-white shadow-sm">

          <div className="border-b border-slate-200 p-5">
            <h2 className="text-xl font-black">
              Mängelliste
            </h2>
          </div>

          {maengel.length === 0 && (
            <div className="p-10 text-center">
              <div className="text-4xl">✓</div>
              <h3 className="mt-3 font-black">
                Keine Mängel erfasst
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Aktuell sind keine Feststellungen dokumentiert.
              </p>
            </div>
          )}

          <div className="divide-y divide-slate-100">

            {maengel.map((mangel) => (
              <div
                key={mangel.id}
                className={`p-5 ${
                  mangel.status === "behoben"
                    ? "bg-green-50/30"
                    : mangel.prioritaet === "kritisch"
                    ? "bg-red-50"
                    : ""
                }`}
              >

                <div className="flex flex-col justify-between gap-4 lg:flex-row">

                  <div className="flex gap-4">

                    <div
                      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-black ${
                        mangel.status === "behoben"
                          ? "bg-green-600 text-white"
                          : mangel.prioritaet === "kritisch"
                          ? "bg-red-600 text-white"
                          : mangel.prioritaet === "hoch"
                          ? "bg-[#F2B632] text-black"
                          : "bg-slate-900 text-white"
                      }`}
                    >
                      {mangel.status === "behoben" ? "✓" : "!"}
                    </div>

                    <div>
                      <div className="flex flex-wrap gap-2">

                        <strong>{mangel.titel}</strong>

                        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black uppercase">
                          {mangel.prioritaet}
                        </span>

                        <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-bold">
                          {mangel.quelle}
                        </span>

                      </div>

                      {mangel.beschreibung && (
                        <p className="mt-2 max-w-2xl text-sm text-slate-600">
                          {mangel.beschreibung}
                        </p>
                      )}

                      <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-500">
                        {mangel.verantwortlich && (
                          <span>
                            Verantwortlich: <strong>{mangel.verantwortlich}</strong>
                          </span>
                        )}

                        {mangel.frist && (
                          <span>
                            Frist: <strong>{mangel.frist}</strong>
                          </span>
                        )}
                      </div>
                    </div>

                  </div>

                  <div className="flex flex-wrap gap-2">

                    {mangel.status !== "in-bearbeitung" &&
                      mangel.status !== "behoben" && (
                        <button
                          onClick={() =>
                            statusAendern(
                              mangel.id,
                              "in-bearbeitung"
                            )
                          }
                          className="rounded-xl bg-[#fff2cc] px-4 py-2 text-xs font-black text-[#8d6000]"
                        >
                          In Bearbeitung
                        </button>
                      )}

                    {mangel.status !== "behoben" && (
                      <button
                        onClick={() =>
                          statusAendern(mangel.id, "behoben")
                        }
                        className="rounded-xl bg-green-600 px-4 py-2 text-xs font-black text-white"
                      >
                        ✓ Behoben
                      </button>
                    )}

                    {mangel.status === "behoben" && (
                      <span className="rounded-xl bg-green-100 px-4 py-2 text-xs font-black text-green-700">
                        Erledigt
                      </span>
                    )}

                  </div>

                </div>

              </div>
            ))}

          </div>

        </section>

      </div>
    </main>
  );
}
