"use client";

import { useEffect, useState } from "react";

type Instruktion = {
  id: string;
  mitarbeiterId: string;
  mitarbeiterName: string;
  funktion: string;
  baustelleId: string;
  baustelle: string;
  code: string;
  bezeichnung: string;
  datum: string;
  verantwortlich: string;
};

export default function Instruktionen() {
  const [historie, setHistorie] = useState<Instruktion[]>([]);

  useEffect(() => {
    const daten = JSON.parse(
      localStorage.getItem("instruktionshistorie") || "[]"
    );

    setHistorie(
      daten.sort((a: Instruktion, b: Instruktion) =>
        b.datum.localeCompare(a.datum)
      )
    );
  }, []);

  return (
    <main className="min-h-screen bg-slate-50">

      <header className="border-b bg-white">

        <div className="mx-auto max-w-7xl px-6 py-5">

          <a
            href="/"
            className="text-sm text-slate-500"
          >
            ← Dashboard
          </a>

          <h1 className="mt-2 text-2xl font-bold">
            Instruktionen
          </h1>

          <p className="text-sm text-slate-500">
            Schulungs- und Instruktionsnachweise
          </p>

        </div>

      </header>

      <div className="mx-auto max-w-7xl p-6">

        <div className="overflow-hidden rounded-2xl border bg-white shadow-sm">

          <div className="border-b p-5">

            <h2 className="text-lg font-bold">
              Instruktionshistorie
            </h2>

            <p className="text-sm text-slate-500">
              {historie.length} Nachweise gespeichert
            </p>

          </div>

          {historie.length === 0 ? (

            <div className="p-12 text-center">

              <div className="text-lg font-bold">
                Noch keine Instruktionen
              </div>

              <p className="mt-2 text-slate-500">
                Abgeschlossene AS5- und AS7-Checklisten
                erscheinen automatisch hier.
              </p>

            </div>

          ) : (

            <div className="divide-y">

              {historie.map((eintrag) => (

                <div
                  key={eintrag.id}
                  className="p-5"
                >

                  <div className="flex flex-col justify-between gap-4 md:flex-row">

                    <div>

                      <div className="flex items-center gap-3">

                        <span className="rounded-lg bg-yellow-400 px-3 py-1 text-xs font-bold text-black">
                          {eintrag.code}
                        </span>

                        <span className="font-bold">
                          {eintrag.mitarbeiterName}
                        </span>

                      </div>

                      <div className="mt-2 text-sm text-slate-500">
                        {eintrag.funktion}
                      </div>

                      <div className="mt-3 font-medium">
                        {eintrag.bezeichnung}
                      </div>

                      <div className="mt-1 text-sm text-slate-500">
                        {eintrag.baustelle}
                      </div>

                    </div>

                    <div className="md:text-right">

                      <div className="font-semibold">
                        {eintrag.datum}
                      </div>

                      {eintrag.verantwortlich && (
                        <div className="mt-1 text-sm text-slate-500">
                          Instruktion: {eintrag.verantwortlich}
                        </div>
                      )}

                      <a
                        href={`/baustellen/${eintrag.baustelleId}`}
                        className="mt-3 inline-block text-sm font-bold text-yellow-600"
                      >
                        Baustelle öffnen →
                      </a>

                    </div>

                  </div>

                </div>

              ))}

            </div>

          )}

        </div>

      </div>

    </main>
  );
}
