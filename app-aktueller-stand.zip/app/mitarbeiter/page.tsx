"use client";

import { useEffect, useState } from "react";

type Mitarbeiter = {
  id: string;
  vorname: string;
  nachname: string;
  funktion: string;
  telefon: string;
  aktiv: boolean;
};

export default function MitarbeiterSeite() {
  const [mitarbeiter, setMitarbeiter] = useState<Mitarbeiter[]>([]);
  const [vorname, setVorname] = useState("");
  const [nachname, setNachname] = useState("");
  const [funktion, setFunktion] = useState("Asbestsanierer");
  const [telefon, setTelefon] = useState("");

  useEffect(() => {
    setMitarbeiter(
      JSON.parse(localStorage.getItem("mitarbeiter") || "[]")
    );
  }, []);

  function speichernListe(liste: Mitarbeiter[]) {
    setMitarbeiter(liste);
    localStorage.setItem("mitarbeiter", JSON.stringify(liste));
  }

  function hinzufuegen() {
    if (!vorname.trim() || !nachname.trim()) {
      alert("Bitte Vorname und Nachname eingeben.");
      return;
    }

    const neu: Mitarbeiter = {
      id: crypto.randomUUID(),
      vorname: vorname.trim(),
      nachname: nachname.trim(),
      funktion,
      telefon: telefon.trim(),
      aktiv: true,
    };

    speichernListe([...mitarbeiter, neu]);

    setVorname("");
    setNachname("");
    setTelefon("");
    setFunktion("Asbestsanierer");
  }

  function statusAendern(id: string) {
    speichernListe(
      mitarbeiter.map((m) =>
        m.id === id ? { ...m, aktiv: !m.aktiv } : m
      )
    );
  }

  function entfernen(id: string) {
    if (!confirm("Mitarbeiter wirklich löschen?")) return;

    speichernListe(
      mitarbeiter.filter((m) => m.id !== id)
    );
  }

  return (
    <main className="min-h-screen bg-slate-50">

      <header className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-6 py-5">

          <a href="/" className="text-sm text-slate-500">
            ← Dashboard
          </a>

          <h1 className="mt-2 text-2xl font-bold">
            Mitarbeiter
          </h1>

          <p className="text-sm text-slate-500">
            B&B Schadstoffsanierung
          </p>

        </div>
      </header>

      <div className="mx-auto max-w-7xl space-y-6 p-6">

        <section className="rounded-2xl border bg-white p-6 shadow-sm">

          <h2 className="text-lg font-bold">
            Mitarbeiter erfassen
          </h2>

          <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-4">

            <Feld
              label="Vorname"
              value={vorname}
              onChange={setVorname}
            />

            <Feld
              label="Nachname"
              value={nachname}
              onChange={setNachname}
            />

            <div>
              <label className="mb-2 block text-sm font-semibold">
                Funktion
              </label>

              <select
                value={funktion}
                onChange={(e) => setFunktion(e.target.value)}
                className="w-full rounded-xl border border-slate-300 px-4 py-3"
              >
                <option>Asbestsanierer</option>
                <option>Vorarbeiter</option>
                <option>Spezialist Asbestsanierung</option>
                <option>Projektleiter</option>
                <option>Fachbauleiter</option>
                <option>Temporärmitarbeiter</option>
                <option>Andere</option>
              </select>
            </div>

            <Feld
              label="Telefon"
              value={telefon}
              onChange={setTelefon}
            />

          </div>

          <button
            type="button"
            onClick={hinzufuegen}
            className="mt-5 rounded-xl bg-yellow-400 px-6 py-3 font-bold text-black hover:bg-yellow-500"
          >
            + Mitarbeiter hinzufügen
          </button>

        </section>

        <section className="overflow-hidden rounded-2xl border bg-white shadow-sm">

          <div className="border-b p-5">
            <h2 className="text-lg font-bold">
              Mitarbeiterstamm
            </h2>

            <p className="text-sm text-slate-500">
              {mitarbeiter.filter((m) => m.aktiv).length} aktive Mitarbeiter
            </p>
          </div>

          {mitarbeiter.length === 0 ? (

            <div className="p-10 text-center text-slate-500">
              Noch keine Mitarbeiter erfasst.
            </div>

          ) : (

            <div className="divide-y">

              {mitarbeiter.map((m) => (

                <div
                  key={m.id}
                  className="flex flex-col justify-between gap-4 p-5 md:flex-row md:items-center"
                >

                  <div>

                    <div className="text-lg font-bold">
                      {m.vorname} {m.nachname}
                    </div>

                    <div className="mt-1 text-sm text-slate-500">
                      {m.funktion}
                      {m.telefon && ` · ${m.telefon}`}
                    </div>

                  </div>

                  <div className="flex items-center gap-3">

                    <button
                      onClick={() => statusAendern(m.id)}
                      className={`rounded-full px-4 py-2 text-sm font-semibold ${
                        m.aktiv
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-slate-200 text-slate-600"
                      }`}
                    >
                      {m.aktiv ? "Aktiv" : "Inaktiv"}
                    </button>

                    <button
                      onClick={() => entfernen(m.id)}
                      className="rounded-xl border px-4 py-2 text-sm font-semibold text-red-600"
                    >
                      Löschen
                    </button>

                  </div>

                </div>

              ))}

            </div>

          )}

        </section>

      </div>

    </main>
  );
}

function Feld({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>

      <label className="mb-2 block text-sm font-semibold">
        {label}
      </label>

      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-yellow-500"
      />

    </div>
  );
}
