"use client";

import { useRef, useState } from "react";

type Props = {
  value?: string;
  onChange: (value: string) => void;
  label?: string;
};

export default function SignaturePad({
  value = "",
  onChange,
  label = "Unterschrift",
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [drawing, setDrawing] = useState(false);

  function getPosition(
    e: React.PointerEvent<HTMLCanvasElement>
  ) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();

    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  }

  function start(
    e: React.PointerEvent<HTMLCanvasElement>
  ) {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const p = getPosition(e);

    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#000";

    ctx.beginPath();
    ctx.moveTo(p.x, p.y);

    setDrawing(true);
  }

  function move(
    e: React.PointerEvent<HTMLCanvasElement>
  ) {
    if (!drawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const p = getPosition(e);

    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  }

  function stop() {
    if (!drawing) return;

    setDrawing(false);

    const canvas = canvasRef.current;
    if (!canvas) return;

    onChange(canvas.toDataURL("image/png"));
  }

  function clear() {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange("");
  }

  return (
    <div>
      <label className="mb-2 block text-sm font-semibold">
        {label}
      </label>

      <div className="rounded-xl border border-slate-300 bg-white">
        {value && (
          <img
            src={value}
            alt="Gespeicherte Unterschrift"
            className="h-24 w-full object-contain"
          />
        )}

        <canvas
          ref={canvasRef}
          width={900}
          height={220}
          onPointerDown={start}
          onPointerMove={move}
          onPointerUp={stop}
          onPointerLeave={stop}
          className="h-40 w-full touch-none cursor-crosshair"
        />
      </div>

      <button
        type="button"
        onClick={clear}
        className="mt-2 text-sm font-semibold text-red-600"
      >
        Unterschrift löschen
      </button>
    </div>
  );
}
