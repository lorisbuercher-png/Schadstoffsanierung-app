"use client";

import { useState } from "react";

export type DateiEintrag = {
  id: string;
  name: string;
  type: string;
  size: number;
  dataUrl?: string;
};

type Props = {
  value: DateiEintrag[];
  onChange: (files: DateiEintrag[]) => void;
};

export default function FileUpload({
  value,
  onChange,
}: Props) {
  const [busy, setBusy] = useState(false);

  async function handleFiles(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const files = Array.from(event.target.files || []);

    if (!files.length) return;

    setBusy(true);

    const neueDateien: DateiEintrag[] = [];

    for (const file of files) {
      const eintrag: DateiEintrag = {
        id: crypto.randomUUID(),
        name: file.name,
        type: file.type,
        size: file.size,
      };

      if (
        file.type.startsWith("image/") &&
        file.size <= 4 * 1024 * 1024
      ) {
        eintrag.dataUrl = await toDataUrl(file);
      }

      neueDateien.push(eintrag);
    }

    onChange([...value, ...neueDateien]);

    event.target.value = "";
    setBusy(false);
  }

  function entfernen(id: string) {
    onChange(value.filter((datei) => datei.id !== id));
  }

  return (
    <div>
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6">

        <label className="block cursor-pointer text-center">

          <div className="font-bold">
            Fotos oder Dateien hinzufügen
          </div>

          <div className="mt-1 text-sm text-slate-500">
            Bilder, PDF und weitere Dokumente
          </div>

          <span className="mt-4 inline-block rounded-xl bg-yellow-400 px-5 py-3 font-bold text-black hover:bg-yellow-500">
            + Datei auswählen
          </span>

          <input
            type="file"
            multiple
            accept="image/*,.pdf"
            onChange={handleFiles}
            className="hidden"
          />

        </label>

      </div>

      {busy && (
        <p className="mt-3 text-sm text-slate-500">
          Dateien werden vorbereitet...
        </p>
      )}

      {value.length > 0 && (
        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">

          {value.map((datei) => (
            <div
              key={datei.id}
              className="overflow-hidden rounded-xl border bg-white"
            >

              {datei.dataUrl ? (
                <img
                  src={datei.dataUrl}
                  alt={datei.name}
                  className="h-40 w-full object-cover"
                />
              ) : (
                <div className="flex h-40 items-center justify-center bg-slate-100 text-4xl">
                  📄
                </div>
              )}

              <div className="p-4">

                <div className="truncate font-semibold">
                  {datei.name}
                </div>

                <div className="mt-1 text-xs text-slate-500">
                  {formatSize(datei.size)}
                </div>

                <button
                  type="button"
                  onClick={() => entfernen(datei.id)}
                  className="mt-3 text-sm font-semibold text-red-600"
                >
                  Entfernen
                </button>

              </div>

            </div>
          ))}

        </div>
      )}
    </div>
  );
}

function toDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;

    reader.readAsDataURL(file);
  });
}

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024)
    return `${Math.round(bytes / 1024)} KB`;

  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
