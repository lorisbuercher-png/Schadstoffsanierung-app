"use client";

import "./ui.css";
import type { ReactNode } from "react";
import { usePathname } from "next/navigation";

type AppShellProps = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  backHref?: string;
  backLabel?: string;
  action?: ReactNode;
};

const navigation = [
  { href: "/", icon: "⌂", label: "Übersicht" },
  { href: "/baustellen", icon: "▦", label: "Baustellen" },
  { href: "/instruktionen", icon: "✓", label: "Checklisten" },
  { href: "/baustellen", icon: "▤", label: "Dokumente" },
  { href: "/baustellen", icon: "⚙", label: "Geräte" },
  { href: "/mitarbeiter", icon: "♧", label: "Mitarbeiter" },
  { href: "/kalender", icon: "□", label: "Kalender" },
];

export default function AppShell({
  children,
  title,
  subtitle,
  backHref,
  backLabel = "Zurück",
  action,
}: AppShellProps) {
  const pathname = usePathname();

  function istAktiv(href: string, label: string) {
    if (label === "Baustellen") {
      return pathname.startsWith("/baustellen");
    }

    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  }

  return (
    <div className="bb-shell">
      <aside className="bb-sidebar">
        <div className="bb-brand">
          <div className="bb-brand-mark" aria-hidden="true" />

          <div className="bb-brand-text">
            <strong>B&amp;B</strong>
            <span>Schadstoffsanierung</span>
          </div>
        </div>

        <nav className="bb-nav">
          {navigation.map((eintrag) => (
            <a
              key={eintrag.label}
              href={eintrag.href}
              className={
                istAktiv(eintrag.href, eintrag.label) ? "active" : ""
              }
            >
              <span>{eintrag.icon}</span>
              {eintrag.label}
            </a>
          ))}
        </nav>

        <div className="bb-sidebar-footer">
          <span>◇</span>
          Sicherheit hat Priorität
        </div>
      </aside>

      <main className="bb-main">
        <header className="bb-topbar">
          <div className="bb-topbar-context">
            B&amp;B Projektmanagement
          </div>

          <div className="bb-topbar-actions">
            <button
              className="bb-icon-button"
              type="button"
              aria-label="Benachrichtigungen"
            >
              ♧
              <span className="bb-notification-dot">3</span>
            </button>

            <div className="bb-user-avatar">L</div>
          </div>
        </header>

        <div className="bb-content">
          {(title || backHref || action) && (
            <section className="bb-page-header">
              <div>
                {backHref && (
                  <a href={backHref} className="bb-back-link">
                    ← {backLabel}
                  </a>
                )}

                {title && <h1>{title}</h1>}
                {subtitle && <p>{subtitle}</p>}
              </div>

              {action && (
                <div className="bb-page-header-action">{action}</div>
              )}
            </section>
          )}

          {children}
        </div>
      </main>
    </div>
  );
}
